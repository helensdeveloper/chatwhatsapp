<?php
date_default_timezone_set('Asia/Jakarta');
echo $timestamp = date('D-M-Y - H:i:s');
?>