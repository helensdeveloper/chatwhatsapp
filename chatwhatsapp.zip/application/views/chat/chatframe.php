<div class="chat" data-chat="<?=$id?>">
    <div class="conversation-start">
        <span>Today, 6:48 AM</span>
    </div>
    <div class="bubble you">
        Hello,
    </div>
    <div class="bubble you">
        It's me.
    </div>
    <div class="bubble you">
        I have a question regarding project.
    </div>
</div>