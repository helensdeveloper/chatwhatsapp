<div class="footer-wrapper">
	<div class="footer-section f-section-1">
		<p class="">Copyright © 2020 <a target="_blank" href="<?=base_url('')?>"><?php echo APPS_NAME ?></a>, All rights reserved.</p>
	</div>
	<div class="footer-section f-section-2">
		<p class="">Whatsapp API Server By <a target="_blank" href="<?php echo APPS_DEV_LINK?>"><?php echo APPS_DEV ?></a>, Versi <?php echo APPS_VERSI ?>.</p>
	</div>
</div>