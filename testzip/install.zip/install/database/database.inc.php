<?php
	// application install status
	define('APP_INSTALL', '1');

	// application version
	define('APP_VERSION', '1.0');

	// application name
	define('APP_TITLE', 'Roogent Installation');

	// application description
	define('APP_DESCRIPTION', 'Database Installer Application');

	// application author
	define('APP_AUTHOR', 'Avisitz');

	// application default logo
	define('APP_DEFAULT_LOGO', 'assets/uploads/default-logo.png');
?>