	<div class="text-center">
		<p class="mt-3"><i class="mdi mdi-copyright"></i> <?php echo date('Y '); ?> <?php if ( defined('APP_TITLE') ){ echo APP_TITLE; }else{ echo '<span class="text-danger">Title missing</span>'; } ?></p>
	</div>

	<!-- JS -->
	<script src="../assets/common/js/jquery-2.2.4.min.js"></script>
	<script src="../assets/common/js/bootstrap.min.js"></script>
	<script src="../assets/common/js/bootstrap.bundle.min.js"></script>
	<script src="../assets/common/js/jquery.validate.min.js"></script>
	<script src="../assets/common/js/additional-methods.min.js"></script>
	<script src="../assets/common/js/forms.min.js"></script>
	<script src="../assets/common/js/jquery-confirm.min.js"></script>
	<script src="assets/js/custom-script.js"></script>
	<script src="../assets/js/main.js"></script>

</body>
</html>